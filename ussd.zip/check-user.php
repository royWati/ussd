<?php

include('Apis.php');
var_dump(Apis::register_user("0724490283","0708691402","roy","1234")) ;

?>
